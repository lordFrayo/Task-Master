-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 26, 2024 at 07:49 AM
-- Server version: 10.6.19-MariaDB-cll-lve-log
-- PHP Version: 8.3.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `triptcrc_taskmaster`
--

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `title` varchar(150) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `priority` varchar(50) NOT NULL,
  `dead_line` varchar(100) NOT NULL,
  `stamp_date` varchar(150) NOT NULL,
  `task_id` int(15) NOT NULL,
  `color` varchar(50) NOT NULL,
  `user_id` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`title`, `description`, `priority`, `dead_line`, `stamp_date`, `task_id`, `color`, `user_id`) VALUES
('AGain', 'ssss', 'Low', '2024-11-29', '2024-11-24 09:54:50', 1, 'primary-bg', 'eb476819-b812-48e6-a641-ba8a01c5db0f'),
('Edited Task something removed again', 'Hello I just edited the task', 'Medium', '2024-11-30', '2024-11-24 10:01:30', 2, 'secondary-bg', '1329'),
('Testing of 3MTT project', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus itaque quibusdam mollitia qui, similique eos a porro dolore, quisquam impedit amet quidem. Quos ea, quibusdam reprehenderit autem nemo ab ipsam.\r\n ', 'High', '2024-11-28', '2024-11-25 09:16:46', 3, 'info-bg', '1326'),
('MIT Assignment ', 'MIT assignment ', 'High', '2024-11-27', '2024-11-25 09:20:24', 4, 'danger-bg', ''),
('MIT Assignment Edited to this by Engr. Kenp', 'MIT assignment deadline', 'High', '2024-11-27', '2024-11-25 09:31:20', 5, 'info-bg', '1332'),
('test', 'this is a testing data', 'Medium', '2024-11-27', '2024-11-25 09:31:58', 6, 'warning-bg', '1329'),
('test', 'this is a testing data', 'Medium', '2024-11-27', '2024-11-25 09:31:59', 7, 'warning-bg', '1329'),
('Attending Seminar', 'I will be attending an MIT tech conference.', 'Medium', '2024-11-30', '2024-11-25 10:47:03', 11, 'warning-bg', '1332'),
('MIT class', 'MIT class attendence', 'High', '2024-11-29', '2024-11-25 13:17:49', 12, 'secondary-bg', '1332');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(150) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `reg_date` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `email`, `phone`, `address`, `password`, `reg_date`) VALUES
(72, 'Peter Gabriel', 'gabrielkehinde001@gmail.com', '08130146023', 'No 192 Universal, Medical junction, Benin City', '0cc175b9c0f1b6a831c399e269772661', '2024-11-24 09:08:08'),
(1335, 'Engr. Ken.', 'gabrielkehinde001@gmail.com', '08130146023', 'Remlek, Badore, Ajah', '0cc175b9c0f1b6a831c399e269772661', '2024-11-25 17:46:24'),
(1336, 'Ajayi Friday', 'fri.ajayi@gmail.com', '08161571646', 'Chevron drive, Lekki Paradise Estate opp. Ebeano supermarket, Chevron-Lekki, Lagos-State.', '202cb962ac59075b964b07152d234b70', '2024-11-26 06:11:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`task_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `task_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(150) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1337;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
